const express = require("express");
const cors = require("cors"); // ✅ Lägg till cors
const db = require("better-sqlite3")("./datab.db"); // Kontrollera sökvägen
const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(express.json());

// ✅ Testroute för att kolla att servern kör
app.get("/", (req, res) => {
  res.send("Servern är igång! 🚀");
});

// ✅ Hämta alla trådar
app.get("/api/threads", (req, res) => {
  try {
    const threads = db.prepare("SELECT * FROM threads ORDER BY created_at DESC").all();
    res.status(200).json(threads);
  } catch (error) {
    res.status(500).json({ message: "Något gick fel vid hämtning av trådar", error });
  }
});

// ✅ Skapa en ny tråd
app.post("/api/threads", (req, res) => {
  const { title, content } = req.body;
  if (!title || !content) {
    return res.status(400).json({ message: "Titel och innehåll är obligatoriska" });
  }

  try {
    const insertThread = db.prepare("INSERT INTO threads (title, content, created_at) VALUES (?, ?, DATETIME('now'))");
    const result = insertThread.run(title, content);
    res.status(201).json({ message: "Tråd skapad", threadId: result.lastInsertRowid });
  } catch (error) {
    res.status(500).json({ message: "Fel vid skapande av tråd", error });
  }
});

// ✅ Hämta kommentarer för en tråd
app.get("/api/threads/:id/replays", (req, res) => {
  const { id } = req.params;
  try {
    const replays = db.prepare("SELECT * FROM replays WHERE thread_id = ? ORDER BY created_at DESC").all(id);
    res.status(200).json(replays);
  } catch (error) {
    res.status(500).json({ message: "Fel vid hämtning av kommentarer", error });
  }
});

// ✅ Skapa en ny kommentar
app.post("/api/threads/:id/replays", (req, res) => {
  const { content } = req.body;
  const { id } = req.params;

  if (!content) {
    return res.status(400).json({ message: "Kommentarinnehåll är obligatoriskt" });
  }

  try {
    const insertReplay = db.prepare(
      "INSERT INTO replays (thread_id, content, created_at, updated_at) VALUES (?, ?, DATETIME('now'), DATETIME('now'))"
    );
    const result = insertReplay.run(id, content);
    res.status(201).json({ message: "Kommentar postad", replayId: result.lastInsertRowid });
  } catch (error) {
    res.status(500).json({ message: "Fel vid skapande av kommentar", error });
  }
});

// ✅ Starta servern
app.listen(PORT, () => {
  console.log(`Servern kör på http://localhost:${3000}`);
});
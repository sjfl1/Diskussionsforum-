import React, { createContext, useState } from 'react';

export const ThreadContext = createContext();

export const ThreadProvider = ({ children }) => {
  const [threads, setThreads] = useState([]);

  const addThread = (newThread) => {
    setThreads([newThread, ...threads]);
  };

  const getThread = (threadId) => {
    return threads.find(thread => thread.id === threadId) || null;
  };

  const addReply = (threadId, reply) => {
    setThreads(threads.map(thread => {
      if (thread.id === threadId) {
        return {
          ...thread,
          replies: [...thread.replies, reply]
        };
      }
      return thread;
    }));
  };

  return (
    <ThreadContext.Provider value={{ threads, addThread, getThread, addReply }}>
      {children}
    </ThreadContext.Provider>
  );
};
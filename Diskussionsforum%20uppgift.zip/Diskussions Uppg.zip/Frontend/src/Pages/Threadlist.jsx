import React, { useContext, useState } from 'react';
import { ThreadContext } from '../context/ThreadContext.jsx';

const ThreadList = () => {
  const { threads, addReply } = useContext(ThreadContext);
  const [replyAuthor, setReplyAuthor] = useState(''); // State för kommentatorns namn
  const [replyText, setReplyText] = useState(''); // State för kommentarens innehåll
  const [activeThreadId, setActiveThreadId] = useState(null); // State för att hålla reda på vilken tråd som är aktiv

  const handleAddReply = (threadId) => {
    if (!replyAuthor.trim() || !replyText.trim()) {
      alert('Please fill in both fields.'); // Validera att båda fälten är ifyllda
      return;
    }

    const newReply = {
      id: Date.now(), // Unikt ID för kommentaren
      author: replyAuthor, // Kommentatorns namn
      text: replyText, // Kommentarens innehåll
    };
    addReply(threadId, newReply); // Lägg till kommentaren i tråden
    setReplyAuthor(''); // Återställ inputfältet för kommentatorns namn
    setReplyText(''); // Återställ inputfältet för kommentarens innehåll
    setActiveThreadId(null); // Stäng reply-formuläret
  };

  return (
    <div>
      <h2>Threads</h2>
      {threads.map(thread => (
        <div key={thread.id} style={{ marginBottom: '20px', border: '1px solid #ccc', padding: '10px' }}>
          <h3>{thread.author}</h3>
          <p>{thread.content}</p>
          <div>
            <strong>Replies:</strong>
            {thread.replies.map(reply => (
              <div key={reply.id} style={{ marginLeft: '20px' }}>
                <p><strong>{reply.author}:</strong> {reply.text}</p>
              </div>
            ))}
          </div>
          {activeThreadId === thread.id ? (
            <div>
              <input
                type="text"
                placeholder="Skriv ditt namn"
                value={replyAuthor}
                onChange={(e) => setReplyAuthor(e.target.value)}
              />
              <textarea
                placeholder="Skriv ditt svar här"
                value={replyText}
                onChange={(e) => setReplyText(e.target.value)}
              />
              <button onClick={() => handleAddReply(thread.id)}>Posta!</button>
              <button onClick={() => setActiveThreadId(null)}>Avbryt</button>
            </div>
          ) : (
            <button onClick={() => setActiveThreadId(thread.id)}>Svar</button>
          )}
        </div>
      ))}
    </div>
  );
};

export default ThreadList;
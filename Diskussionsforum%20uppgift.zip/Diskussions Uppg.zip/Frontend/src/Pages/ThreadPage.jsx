import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import ReplayList from "../components/ReplayList"; // Korrekt relativ sökväg
import ReplayForm from "../components/ReplayForm";

const ThreadPage = () => {
  const { id } = useParams(); // Hämta trådens ID från URL-parametrarna
  const [thread, setThread] = useState(null);
  const [replays, setReplays] = useState([]);
  const [newReplay, setNewReplay] = useState("");
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchThread = async () => {
      try {
        const response = await fetch(`http://localhost:3000/api/threads/${id}`);
        if (!response.ok) {
          throw new Error("Failed to fetch thread");
        }
        const data = await response.json();
        setThread(data);
      } catch (error) {
        setError(error.message);
      }
    };

    const fetchReplays = async () => {
      try {
        const response = await fetch(`http://localhost:3000/api/threads/${id}/replays`);
        if (!response.ok) {
          throw new Error("Failed to fetch replays");
        }
        const data = await response.json();
        setReplays(data);
      } catch (error) {
        setError(error.message);
      }
    };

    fetchThread();
    fetchReplays();
  }, [id]);

  // Posta en ny kommentar
  const handlePostReply = async (newReplayContent) => {
    if (!newReplayContent.trim()) {
      return;
    }

    try {
      const response = await fetch(`http://localhost:3000/api/threads/${id}/replays`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ content: newReplayContent }),
      });

      if (!response.ok) {
        throw new Error("Failed to post reply");
      }

      const data = await response.json();

      setReplays((prevReplays) => [...prevReplays, { content: newReplayContent, created_at: new Date().toISOString() }]);
      setNewReplay("");
    } catch (error) {
      setError(error.message);
    }
  };

  return (
    <div className="thread-page">
      {error && <p className="error-message">{error}</p>}
      
      {thread ? (
        <div>
          <h1>{thread.title}</h1>
          <p>{thread.content}</p>
          <hr />
          
          <div>
            <h3>Comments (Replays)</h3>
            <ReplayList replays={replays} />
          </div>

          <ReplayForm onSubmit={handlePostReply} newReplay={newReplay} setNewReplay={setNewReplay} />
        </div>
      ) : (
        <p>Loading thread...</p>
      )}
    </div>
  );
};

export default ThreadPage;

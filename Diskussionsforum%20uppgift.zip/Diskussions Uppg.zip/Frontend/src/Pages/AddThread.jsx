import React, { useContext, useState } from 'react';
import { ThreadContext } from '../context/ThreadContext.jsx';
import './AddThread.css';  // Importera CSS-filen för styling

const AddThread = () => {
  const { addThread } = useContext(ThreadContext);
  const [author, setAuthor] = useState(''); // State för författarens namn
  const [content, setContent] = useState(''); // State för trådens innehåll

  const handleAddThread = (e) => {
    e.preventDefault(); // Förhindra att formuläret laddar om sidan

    // Validera att båda fälten är ifyllda
    if (!author.trim() || !content.trim()) {
      alert('Vänligen fyll i båda fälten.');
      return;
    }

    // Skapa en ny tråd
    const newThread = {
      id: Date.now(), // Unikt ID för tråden
      author: author, // Författarens namn
      content: content, // Trådens innehåll
      replies: [], // Tom lista för kommentarer
    };

    // Lägg till tråden i kontexten
    addThread(newThread);

    // Återställ inputfälten efter att tråden har skapats
    setAuthor('');
    setContent('');
  };

  return (
    <div className="add-thread-container">
      <h2>Skapa en diskussionstråd</h2>
      <form onSubmit={handleAddThread}>
        <div className="input-container">
          <label htmlFor="author">Skapad av</label>
          <input
            type="text"
            id="author"
            placeholder="Skriv ditt namn"
            value={author}
            onChange={(e) => setAuthor(e.target.value)}
          />
        </div>
        <div className="input-container">
          <label htmlFor="content">Trådinnehåll:</label>
          <textarea
            id="content"
            placeholder="Vad vill du diskutera idag?"
            value={content}
            onChange={(e) => setContent(e.target.value)}
          />
        </div>
        <button type="submit">Skapa tråd</button>
      </form>
    </div>
  );
};

export default AddThread;

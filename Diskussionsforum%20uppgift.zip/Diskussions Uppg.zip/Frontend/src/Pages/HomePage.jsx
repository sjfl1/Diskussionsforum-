import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

function Home() {
  const [threads, setThreads] = useState([]);

  useEffect(() => {
    fetch("http://localhost:5173/api/threads")
      .then((res) => res.json())
      .then((data) => setThreads(data))
      .catch((error) => console.error("Fel vid hämtning av trådar:", error));
  }, []);

  return (
    <div>
      <h1>Diskussionsforum</h1>
      <ThreadForm setThreads={setThreads} />
      <ul>
        {threads.map((thread) => (
          <li key={thread.id}>
            <Link to={`/thread/${thread.id}`}>{thread.title}</Link>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Home;

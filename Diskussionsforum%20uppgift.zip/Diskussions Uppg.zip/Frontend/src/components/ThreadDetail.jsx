// src/components/ThreadDetail.js

import React, { useContext, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import ThreadContext from '../context/ThreadContext';
import AddReplay from './ReplayList';

const ThreadDetail = () => {
  const { threadId } = useParams();
  const { threads, replays, getReplays } = useContext(ThreadContext);

  useEffect(() => {
    getReplays(threadId);
  }, [threadId, getReplays]);

  const thread = threads.find((t) => t.thread_id === parseInt(threadId));

  return (
    <div>
      <h2>{thread ? thread.title : 'Tråd ej funnen'}</h2>
      <p>{thread ? thread.content : ''}</p>
      <h3>Kommentarer</h3>
      <ul>
        {replays.map((replay) => (
          <li key={replay.replay_id}>{replay.content}</li>
        ))}
      </ul>
      <AddReplay threadId={threadId} />
    </div>
  );
};

export default ThreadDetail;

// components/ReplayList.jsx
import React from 'react';

const ReplayList = ({ replays }) => {
  return (
    <div>
      {replays.length > 0 ? (
        replays.map((replay) => (
          <div key={replay.id} className="replay">
            <p>{replay.content}</p>
          </div>
        ))
      ) : (
        <p>No comments yet.</p>
      )}
    </div>
  );
};

export default ReplayList;

import React from "react";

const ReplayForm = ({ onSubmit, newReplay, setNewReplay }) => {
  const handleChange = (event) => {
    setNewReplay(event.target.value); // Uppdatera newReplay när användaren skriver
  };

  const handleSubmit = (event) => {
    event.preventDefault(); // Förhindra att sidan laddas om
    onSubmit(newReplay); // Skicka den nya kommentaren till handlePostReply
  };

  return (
    <form onSubmit={handleSubmit}>
      <textarea
        value={newReplay}
        onChange={handleChange}
        placeholder="Write your reply here..."
      />
      <button type="submit">Post Reply</button>
    </form>
  );
};

export default ReplayForm;

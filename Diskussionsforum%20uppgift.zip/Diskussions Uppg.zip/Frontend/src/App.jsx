import React from 'react';
import { ThreadProvider } from './context/ThreadContext.jsx';
import AddThread from './Pages/AddThread.jsx';
import ThreadList from './Pages/ThreadList.jsx';

function App() {
  return (
    <ThreadProvider>
      <div>
        <h1>Diskussionsforum</h1>
        <AddThread />
        <ThreadList />
      </div>
    </ThreadProvider>
  );
}

export default App;
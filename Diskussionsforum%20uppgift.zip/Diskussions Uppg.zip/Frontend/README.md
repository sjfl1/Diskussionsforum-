# Disskussionsforum

Ett enkelt diskussionsforum byggt med React för frontend och Node.js/Express för backend.

## Installation

### Backend

1. Navigera till `backend/`-mappen.
2. Kör `npm install` för att installera beroenden.
3. Skapa en `.env`-fil och lägg till din databasanslutningssträng.
4. Kör `npm start` för att starta servern.

### Frontend

1. Navigera till `frontend/`-mappen.
2. Kör `npm install` för att installera beroenden.
3. Kör `npm start` för att starta React-appen.

